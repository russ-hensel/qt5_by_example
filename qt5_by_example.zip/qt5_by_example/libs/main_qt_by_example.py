# -*- coding: utf-8 -*-
"""



"""
import os
os.chdir( "/mnt/WIN_D/russ/0000/python00/python3/_projects/qt5_by_example" )
#os.chdir( "/home/russ/Documents/kw25/Russ/0000/python00/python3/_projects/qt5_by_example" )


import adjust_path
import qt5_by_example

qt5_by_example.main()
