#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 30 17:28:40 2024

@author: russ
"""




        sort order for classes may not be right
        look at auto extension of the path to find modules
              match parameters
        get in old code
        test of course

        more document