# -*- coding: utf-8 -*-
"""



"""


import adjust_path
import qt5_by_example

qt5_by_example.main()
