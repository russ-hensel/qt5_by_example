# qt_by_example

The plan for this is to have a small number of applications that illustrate the
use of many of qt's widgets.

The applications should be simple and contain code that is closely linked to the
appearance of the widgets.

The code should also be copy and paste ready for other to paste into thier application.

Currently the apps run but are in a fairly sad state.

Whatch for updates and for postings here of any overall change in status.

Status:
    A bit sad, 
    Large percentage of dead code.
    Repo may be incomplete


    
