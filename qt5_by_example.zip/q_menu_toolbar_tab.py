#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Qt.ToolButtonIconOnlyIcon only, no text
Qt.ToolButtonTextOnlyText only, no icon
Qt.ToolButtonTextBesideIconIcon and text, with text beside the
icon
Qt.ToolButtonTextUnderIcon
Icon and text, with text under the
icon
Qt.ToolButtonIconOnlyIcon only, no text
Qt.ToolButtonFollowStyleFollow the host desktop style

toolbar = QToolBar("My main toolbar")
toolbar.setIconSize(QSize(16, 16))
self.addToolBar(toolbar)

"""




